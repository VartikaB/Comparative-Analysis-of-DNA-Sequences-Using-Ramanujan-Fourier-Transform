Please run Main.m file! Thank you!
(Please run GetBacteriaData.m if you want to get bacteria data for testing the method!)