clear all ;
close all ;
set(0,'DefaultFigureWindowStyle','normal');
drawnow;
clc;

TestUPGMA('DNA');                    

fprintf('\n');
